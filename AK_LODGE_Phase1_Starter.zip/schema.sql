-- AK LODGE Phase 1 — Supabase SQL
-- Run this entire file in Supabase Dashboard > SQL Editor > New query.
-- Important: never put the service_role key in the website.

create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create type public.app_role as enum ('owner', 'manager', 'customer');
create type public.booking_status as enum ('pending', 'confirmed', 'rejected', 'cancelled', 'checked_in', 'checked_out', 'no_show');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now()
);

create table public.rooms (
  id uuid primary key default gen_random_uuid(),
  room_number text not null unique,
  room_type text not null default 'Standard',
  description text not null default '',
  capacity integer not null default 2 check (capacity between 1 and 20),
  price_per_night numeric(10,2) not null default 0 check (price_per_night >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.room_images (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  image_path text not null,
  alt_text text not null default '',
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  booking_code text not null unique default ('AK-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))),
  customer_id uuid not null references auth.users(id) on delete restrict,
  room_id uuid not null references public.rooms(id) on delete restrict,
  guest_name text not null,
  guest_phone text not null,
  guests integer not null default 1 check (guests between 1 and 20),
  check_in date not null,
  check_out date not null,
  nights integer generated always as ((check_out - check_in)) stored,
  nightly_rate numeric(10,2) not null check (nightly_rate >= 0),
  total_amount numeric(10,2) generated always as ((check_out - check_in) * nightly_rate) stored,
  status public.booking_status not null default 'pending',
  terms_accepted boolean not null default false check (terms_accepted = true),
  customer_note text not null default '',
  staff_note text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (check_out > check_in),
  check (guests >= 1)
);

-- This constraint is the final protection against overlapping active bookings
-- for the same physical room, even if two customers submit at the same time.
alter table public.bookings
  add constraint bookings_no_overlapping_active_room_dates
  exclude using gist (
    room_id with =,
    daterange(check_in, check_out, '[)') with &&
  )
  where (status in ('pending', 'confirmed', 'checked_in'));

create index bookings_customer_id_idx on public.bookings(customer_id);
create index bookings_dates_idx on public.bookings(check_in, check_out);
create index bookings_room_status_idx on public.bookings(room_id, status);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger rooms_set_updated_at before update on public.rooms
for each row execute function public.set_updated_at();

create trigger bookings_set_updated_at before update on public.bookings
for each row execute function public.set_updated_at();

-- Create a profile automatically for each newly registered user.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'phone', ''),
    'customer'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- Helpers for role checks. They read the private profile table without exposing role changes.
create or replace function public.current_app_role()
returns public.app_role
language sql stable security definer set search_path = ''
as $$
  select p.role from public.profiles p where p.id = auth.uid()
$$;

create or replace function public.is_staff()
returns boolean
language sql stable security definer set search_path = ''
as $$
  select coalesce(public.current_app_role() in ('owner', 'manager'), false)
$$;

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_images enable row level security;
alter table public.bookings enable row level security;

-- Profiles: users can read/update their own contact details, but cannot change role.
create policy "profiles read self or owner"
on public.profiles for select to authenticated
using (id = auth.uid() or public.current_app_role() = 'owner');

create policy "profiles update own contact fields"
on public.profiles for update to authenticated
using (id = auth.uid())
with check (id = auth.uid() and role = public.current_app_role());

-- Public can view active rooms. Only staff can create/change rooms.
create policy "active rooms visible to everyone"
on public.rooms for select to anon, authenticated
using (is_active = true or public.is_staff());

create policy "staff manage rooms"
on public.rooms for all to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Images for active rooms can be read publicly; staff manages image rows.
create policy "room images readable"
on public.room_images for select to anon, authenticated
using (
  exists (select 1 from public.rooms r where r.id = room_id and (r.is_active = true or public.is_staff()))
);

create policy "staff manage room image rows"
on public.room_images for all to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Booking availability is exposed through a safe RPC below, not by listing all customers' bookings.
-- Customer sees only own bookings; staff sees all.
create policy "customer sees own bookings staff sees all"
on public.bookings for select to authenticated
using (customer_id = auth.uid() or public.is_staff());

-- Customers can only create their own pending bookings, with terms accepted.
create policy "customer creates own pending booking"
on public.bookings for insert to authenticated
with check (
  customer_id = auth.uid()
  and status = 'pending'
  and terms_accepted = true
  and check_out > check_in
  and exists (
    select 1 from public.rooms r
    where r.id = room_id and r.is_active = true and r.capacity >= guests
  )
);

-- Customers can cancel only their own pending booking. Staff can update statuses/notes.
create policy "customer cancel pending booking or staff update"
on public.bookings for update to authenticated
using (
  (customer_id = auth.uid() and status = 'pending')
  or public.is_staff()
)
with check (
  public.is_staff()
  or (
    customer_id = auth.uid()
    and status = 'cancelled'
    and terms_accepted = true
  )
);

-- Do not allow deletes from booking history through the client.

-- Storage bucket for room photos. Create it once; public read, staff upload/update/delete.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('ak-lodge-photos', 'ak-lodge-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "public can view lodge photos"
on storage.objects for select to anon, authenticated
using (bucket_id = 'ak-lodge-photos');

create policy "staff upload lodge photos"
on storage.objects for insert to authenticated
with check (bucket_id = 'ak-lodge-photos' and public.is_staff());

create policy "staff update lodge photos"
on storage.objects for update to authenticated
using (bucket_id = 'ak-lodge-photos' and public.is_staff())
with check (bucket_id = 'ak-lodge-photos' and public.is_staff());

create policy "staff delete lodge photos"
on storage.objects for delete to authenticated
using (bucket_id = 'ak-lodge-photos' and public.is_staff());

-- Secure RPC: returns whether a room is available for requested dates and guest count.
create or replace function public.check_room_available(
  p_room_id uuid,
  p_check_in date,
  p_check_out date,
  p_guests integer default 1
)
returns boolean
language plpgsql stable security definer set search_path = ''
as $$
begin
  if p_check_in is null or p_check_out is null or p_check_out <= p_check_in or p_guests < 1 then
    return false;
  end if;
  return exists (
    select 1
    from public.rooms r
    where r.id = p_room_id
      and r.is_active = true
      and r.capacity >= p_guests
      and not exists (
        select 1 from public.bookings b
        where b.room_id = r.id
          and b.status in ('pending', 'confirmed', 'checked_in')
          and daterange(b.check_in, b.check_out, '[)') && daterange(p_check_in, p_check_out, '[)')
      )
  );
end;
$$;

grant execute on function public.check_room_available(uuid, date, date, integer) to anon, authenticated;

-- Staff can create a room, then add room_images rows.
-- After the first user registers in the app, promote that user to owner manually:
-- update public.profiles set role = 'owner' where id = 'PASTE_AUTH_USER_UUID_HERE';
-- Promote manager similarly:
-- update public.profiles set role = 'manager' where id = 'PASTE_MANAGER_AUTH_USER_UUID_HERE';
