# AK LODGE — Phase 1 (phone-friendly setup)

This starter includes:
- Customer sign-up/login
- Owner/manager roles (staff role is assigned only from Supabase SQL Editor)
- Room inventory and per-night pricing
- Public room photos uploadable by staff
- Date-based availability check
- Customer booking requests and booking history
- Staff dashboard, status updates, price changes, activate/deactivate rooms
- Payment at lodge only; no online payment gateway
- Database-level exclusion constraint to stop overlapping active bookings for the same physical room

## Part A — Create Supabase project (Android phone)
1. Open https://supabase.com/ and sign in/create a free project.
2. Create project `ak-lodge-booking` and save the database password privately.
3. Open Project > SQL Editor > New query.
4. Open `schema.sql` from this package, copy the full contents and paste into SQL Editor.
5. Press Run. Confirm it finishes without errors. If it says a policy already exists, the script may have been run before; don't repeatedly run partial pieces blindly.
6. Open Project Settings > API (sometimes shown as Settings > API Keys).
7. Copy the Project URL and the anon/public key (NOT service_role/secret key).

## Part B — Put keys into index.html
1. Open `index.html` in a text editor that can edit HTML (phone).
2. Find:
   const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
   const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_PUBLIC_KEY";
3. Replace only the text inside the quotes with your Supabase Project URL and anon/public key.
4. Never put a service_role key in index.html, GitHub, screenshots, or chats. The anon/public key is designed to be used in the browser together with correct Row Level Security policies.

## Part C — Publish with GitHub Pages
1. Open https://github.com/ and open your repository. Create a new repository named `ak-lodge-booking` (public for free GitHub Pages).
2. Add/upload `index.html` to the repository root.
3. In repository Settings > Pages, select Deploy from a branch, branch `main`, folder `/(root)`, then Save.
4. Wait a few minutes. Site URL will be `https://YOUR-GITHUB-USERNAME.github.io/ak-lodge-booking/`.
5. Open it. If the setup warning still appears, check the two values in index.html and wait for Pages deployment.

## Part D — Make the first account the owner
Security design intentionally does NOT allow a visitor to become owner by changing a browser field.
1. Open the published app, create your own account with an email and password.
2. In Supabase > Authentication > Users, find your user and copy the UUID.
3. In SQL Editor, run:
   update public.profiles set role = 'owner' where id = 'PASTE-YOUR-UUID-HERE';
4. Log out and log in again in the app. The Admin panel should appear.
5. Add your room numbers, types, capacities and prices. Then upload room photos.

## Part E — Create a manager account
1. Ask the manager to sign up using their own email in your app.
2. In Supabase > Authentication > Users, copy the manager's UUID.
3. In SQL Editor, run:
   update public.profiles set role = 'manager' where id = 'PASTE-MANAGER-UUID-HERE';
4. Manager logs out and logs in again. They will get staff panel access.
5. Never share your owner password with the manager.

## Important notes
- Bookings are requests and begin as `pending`; staff must confirm them.
- Active statuses `pending`, `confirmed`, and `checked_in` reserve the room dates. If a pending request is not accepted, staff should mark it `rejected` or `cancelled`.
- Room count means each physical room is one row in `rooms`. Add each room separately, e.g. 101, 102, 103.
- Availability is date-specific; checkout date is not included as an occupied night.
- Customer-facing terms are a starter notice only. Before accepting real guests, replace it with your final lodge policies and have it reviewed as needed.
- Free service limits can change; check the current Supabase and GitHub plans. Do not assume unlimited storage, uptime or backups.
- Phase 1 does not yet include automated email/SMS/WhatsApp alerts, GST invoices, ID document collection, refund workflows, or a downloadable native Play Store APK.
